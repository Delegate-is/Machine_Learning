import random
from datetime import datetime, date, timedelta
from app import app, db
from models import MilkProduction, Cow, Breeding, Inventory, CalfHealth, Vaccination, HealthRecord

def seed_database():
    with app.app_context():
        print("Clearing existing data and syncing schema...")
        db.drop_all()
        db.create_all()

        # 1. Setup Inventory (Auto-Deduct Ready)
        inventory_items = [
            {'name': 'Iodine', 'qty': 10.0, 'unit': 'Litres', 'min': 2.0},
            {'name': 'Milk Replacer', 'qty': 50.0, 'unit': 'Kg', 'min': 10.0},
            {'name': 'FMD Vaccine', 'qty': 20.0, 'unit': 'Doses', 'min': 5.0}
        ]
        for item in inventory_items:
            db.session.add(Inventory(item_name=item['name'], quantity=item['qty'], unit=item['unit'], min_threshold=item['min']))

        # 2. Detailed Herd Configuration
        herd_data = [
            {'name': 'Njata', 'status': 'Lactating', 'prod': (6, 4, 2), 'breed': 'Jersey'},
            {'name': 'June', 'status': 'Pregnant', 'prod': (5, 0, 6), 'insem': date(2025, 8, 17)},
            {'name': 'Mariru', 'status': 'Pregnant', 'prod': (5, 3, 2), 'insem': date(2026, 3, 5)},
            {'name': 'Madam', 'status': 'Pregnant', 'prod': (8, 6, 3), 'insem': date(2025, 12, 31)},
            {'name': 'Jupiter', 'status': 'Lactating', 'prod': (7, 5, 3), 'breed': 'Holstein'},
            {'name': 'Mahua', 'status': 'Pregnant', 'prod': (0, 0, 0), 'insem': date(2025, 6, 26)}
        ]

        adult_cows = []
        for data in herd_data:
            cow = Cow(
                tag_number=f"M-{data['name'][:3].upper()}", 
                name=data['name'], 
                status=data['status'],
                breed=data.get('breed', 'Friesian')
            )
            db.session.add(cow)
            db.session.flush()
            adult_cows.append(cow)

            # Add Breeding & Milk Records (Logic remains same as previous version)
            if 'insem' in data:
                db.session.add(Breeding(cow_id=cow.id, insemination_date=data['insem'], bull="Elite_Semen_001", expected_calving=data['insem'] + timedelta(days=283)))
            
            sessions = ['Morning', 'Lunch', 'Evening']
            for i, litres in enumerate(data['prod']):
                if litres > 0:
                    db.session.add(MilkProduction(cow_id=cow.id, litres=litres, session=sessions[i], date=datetime.now()))

        # 3. MASS VACCINATION: FMD on 23/03/2026
        fmd_date = date(2026, 3, 23)
        for cow in adult_cows:
            db.session.add(Vaccination(
                cow_id=cow.id,
                vaccine="FMD Vaccine",
                due_date=fmd_date,
                administered_by="Vet Mathenge",
                next_due_date=fmd_date + timedelta(days=180) # FMD is usually bi-annual
            ))

        # 4. HEALTH INCIDENT: Jupiter's FMD Treatment
        # Find Jupiter in our created list
        jupiter_cow = next(c for c in adult_cows if c.name == "Jupiter")
        db.session.add(HealthRecord(
            cow_id=jupiter_cow.id,
            disease="Foot and Mouth Disease (FMD)",
            treatment="Antibiotic & Anti-inflammatory Injection",
            vet_name="Vet Mathenge",
            date=date(2026, 3, 21), # Incident date
            cost=2500.0,
            status="Under Treatment"
        ))

        # 5. Add Young Stock (Heifers and Calves)
        # 4 Young Heifers
        for i in range(1, 5):
            db.session.add(Cow(tag_number=f"H0{i}", name=f"Heifer_{i}", status="Young", breed="Friesian"))

        # 2 Young Female Calves & 2 Young Male Calves
        for i in range(1, 3):
            db.session.add(Cow(tag_number=f"CF0{i}", name=f"F_Calf_{i}", status="Young", breed="Jersey"))
            db.session.add(Cow(tag_number=f"CM0{i}", name=f"M_Calf_{i}", status="Young", breed="Ayrshire"))

        # 2 Lactating Calves (Young animals currently being weaned/monitored)
        for i in range(1, 3):
            db.session.add(Cow(tag_number=f"LC0{i}", name=f"L_Calf_{i}", status="Lactating", breed="Holstein"))

        db.session.commit()
        print("Success! Rebuilt with Mass Vaccination (23/3/26) and Jupiter's Health Incident.")

if __name__ == "__main__":
    seed_database()